function openTab(tabName){
  var contents = document.getElementsByClassName("tab-content");
  for(var i=0;i<contents.length;i++){
    contents[i].classList.remove("active");
  }
  var buttons = document.getElementsByClassName("tab-btn");
  for(var i=0;i<buttons.length;i++){
    buttons[i].classList.remove("active");
  }
  document.getElementById(tabName).classList.add("active");
  event.currentTarget.classList.add("active");
}