# Wede50202
git add .
git commit -m "Updated README for Part 2"
git push
## References

### Images
- Hero image, Meal image, Parcel image, Volunteer image - facebook

### Fonts & Icons
- Google Fonts. (2024). Poppins & Open Sans. [https://fonts.google.com/]

### Code & Tutorials
- W3Schools. (2024). CSS Grid Layout. [https://www.w3schools.com/css/css_grid.asp]
- W3Schools. (2024). Responsive Web Design - Media Queries. [https://www.w3schools.com/css/css_rwd_mediaqueries.asp]
- Mozilla Developer Network. (2024). CSS Basics. [https://developer.mozilla.org/en-US/docs/Web/CSS]

### Content
- All website text is original written for Medicare P Food Parcel Foundation (Non-profit organisation).